### cmake
a cmake hello world project
