#!/usr/bin/env sh

echo "driver_version,uuid,name,driver_model.current,driver_model.pending,vbios_version"
echo "460.91.03,GPU-df6e7a7c-7314-46f8-abc4-b88b36dcf3aa,NVIDIA GeForce RTX 2080 SUPER, WDDM, WDDM, 90.04.7A.40.73"

exit 1
